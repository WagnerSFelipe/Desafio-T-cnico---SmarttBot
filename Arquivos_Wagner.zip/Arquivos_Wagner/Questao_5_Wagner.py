#!/usr/bin/env python
# coding: utf-8

# In[6]:


pip install PyMySQL


# In[1]:


import pymysql
import MySQLdb


# In[2]:


db= MySQLdb.connect("localhost", "root", "master", "dados_desafio")


# In[3]:


cursor= db.cursor()


# In[5]:


meucursor=cursor.execute("select A.salesorderID ,B.OrderDate,TotalDue from sales_salesorderheader_csv B inner join sales_salesorderdetail_csv A on B.SalesOrderID = A.SalesOrderID  where orderdate between '2011-11-01' and '2011-11-31' order by TotalDue desc")


# In[6]:


resultado= cursor.fetchall()


# In[7]:


for x in resultado:
    print(x)


# In[ ]:




