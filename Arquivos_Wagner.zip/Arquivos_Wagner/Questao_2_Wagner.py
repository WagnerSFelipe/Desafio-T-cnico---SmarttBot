#!/usr/bin/env python
# coding: utf-8

# In[6]:


pip install PyMySQL


# In[3]:


import pymysql
import MySQLdb


# In[4]:


db= MySQLdb.connect("localhost", "root", "master", "dados_desafio")


# In[5]:


cursor= db.cursor()


# In[9]:


meucursor=cursor.execute("select A.NAME as NOME_PRODUTO,(select sum(OrderQty) from sales_salesorderdetail_csv) as QTD_VENDIDA,A.DaysToManufacture from  sales_salesorderdetail_csv X inner join production_product_csv A on A.ProductID = X.ProductID group by A.DaysToManufacture having A.DaysToManufacture>0")


# In[16]:


resultado= cursor.fetchall()


# In[19]:


for x in resultado:
    print(x)


# In[ ]:




