#!/usr/bin/env python
# coding: utf-8

# ##Bibliotecas##

# In[6]:


import pandas as pd


# In[5]:


pessoas = pd.read_csv(r'C:\Users\wagner.nascimento\Documents\DesafioDados\dados\Person_Person.csv')


# In[6]:


pessoas.head()


# In[7]:


produtos = pd.read_csv(r'C:\Users\wagner.nascimento\Documents\DesafioDados\dados\Production_Product.csv')


# In[9]:


produtos.head()


# In[10]:


salescustomer = pd.read_csv(r'C:\Users\wagner.nascimento\Documents\DesafioDados\dados\Sales_Customer.csv')


# In[25]:


salescustomer.head()


# In[26]:


pedidodetail = pd.read_csv(r'C:\Users\wagner.nascimento\Documents\DesafioDados\dados\Sales_SalesOrderDetail.csv')


# In[28]:


pedidodetail.head()


# In[29]:


pedidoheader = pd.read_csv(r'C:\Users\wagner.nascimento\Documents\DesafioDados\dados\Sales_SalesOrderHeader.csv')


# In[31]:


pedidoheader.head()


# In[7]:


produtosoffer = pd.read_csv(r'C:\Users\wagner.nascimento\Documents\DesafioDados\dados\Sales_SpecialOfferProduct.csv')


# In[8]:


produtosoffer.head()


# ####Conectar ao Banco###

# In[10]:


get_ipython().system('pip install mysql-connector-python')


# ###Utilizei esta biblioteca para poder conectar ao Banco MySQL###

# In[25]:


pip install mysqlclient


# In[63]:


import mysql.connector


# In[64]:


meudb = mysql.connector.connect(
  host="localhost",
  user="root",
  password="master",
  database="dados_desafio"
)

meucursor = meudb.cursor()


# In[82]:


meucursor.execute("select  count(SalesOrderID) from sales_salesorderdetail_csv group by SalesOrderID having count(SalesOrderID)> 3 ;")


# In[83]:


resultado = (len(meucursor.fetchall()))


# In[86]:


for x in resultado:
  print(x)


# In[ ]:




