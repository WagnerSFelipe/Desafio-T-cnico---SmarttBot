#!/usr/bin/env python
# coding: utf-8

# In[6]:


pip install PyMySQL


# In[1]:


import pymysql
import MySQLdb


# In[2]:


db= MySQLdb.connect("localhost", "root", "master", "dados_desafio")


# In[3]:


cursor= db.cursor()


# In[4]:


meucursor=cursor.execute("select sum(orderQty),ProductID,orderdate,(select name from production_product_csv where sales_salesorderdetail_csv.ProductID = production_product_csv.ProductID) as Name_Produto from sales_salesorderheader_csv inner join sales_salesorderdetail_csv on sales_salesorderheader_csv.SalesOrderID = sales_salesorderdetail_csv.SalesOrderID  group by productID,orderdate")


# In[5]:


resultado= cursor.fetchall()


# In[6]:


for x in resultado:
    print(x)


# In[ ]:




