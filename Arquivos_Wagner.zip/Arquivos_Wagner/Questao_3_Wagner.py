#!/usr/bin/env python
# coding: utf-8

# In[6]:


pip install PyMySQL


# In[1]:


import pymysql
import MySQLdb


# In[2]:


db= MySQLdb.connect("localhost", "root", "master", "dados_desafio")


# In[3]:


cursor= db.cursor()


# In[4]:


meucursor=cursor.execute(" select count(salesorderid),PersonID , Name.Firstname from sales_salesorderheader_csv inner join sales_customer_csv on sales_salesorderheader_csv.CustomerID = sales_customer_csv.CustomerID  inner join person_person_csv Name on sales_customer_csv.CustomerID = Name.BusinessEntityID group by PersonID order by count(salesorderid) desc")


# In[5]:


resultado= cursor.fetchall()


# In[6]:


for x in resultado:
    print(x)


# In[ ]:




