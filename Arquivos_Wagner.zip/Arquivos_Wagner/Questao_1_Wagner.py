#!/usr/bin/env python
# coding: utf-8

# In[6]:


pip install PyMySQL


# In[7]:


import pymysql
import MySQLdb


# In[9]:


db= MySQLdb.connect("localhost", "root", "master", "dados_desafio")


# In[10]:


cursor= db.cursor()


# In[11]:


numero_linhas = cursor.execute("select  count(SalesOrderID) from sales_salesorderdetail_csv group by SalesOrderID having count(SalesOrderID)> 3 ;")


# In[12]:


print(numero_linhas)


# In[ ]:




